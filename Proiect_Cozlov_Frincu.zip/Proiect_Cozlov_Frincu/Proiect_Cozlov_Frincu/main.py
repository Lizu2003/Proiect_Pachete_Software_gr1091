import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, confusion_matrix
import statsmodels.api as sm
from scipy import stats
from statsmodels.stats.diagnostic import het_breuschpagan
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score
from itertools import combinations
import geopandas as gpd

def cluster_specific_interpretations(cluster_data, vars):
    output = []
    
    # Titlu principal
    output.append("# 📊 Caracteristici specifice acestui cluster\n")
    
    for var in vars:
        median = cluster_data[var].median()
        mean = cluster_data[var].mean()
        iqr = cluster_data[var].quantile(0.75) - cluster_data[var].quantile(0.25)
        skew = cluster_data[var].skew()
        
        # Secțiune pentru fiecare variabilă
        output.append(f"## 📈 {var}")
        output.append("---")
        
        # Caracteristici simplificate
        if median > mean:
            output.append("✨ **Tendință:** Valori peste medie")
        else:
            output.append("✨ **Tendință:** Valori sub medie")
        
        if iqr > cluster_data[var].std():
            output.append("📊 **Variabilitate:** Ridicată")
        else:
            output.append("📊 **Variabilitate:** Scăzută")
        
        if abs(skew) < 0.5:
            output.append("🔄 **Distribuție:** Simetrică")
        elif skew > 0:
            output.append("↗️ **Distribuție:** Asimetrică dreapta")
        else:
            output.append("↙️ **Distribuție:** Asimetrică stânga")
        
        output.append("")  # Spațiu între secțiuni
    
    # Implicații simplificate
    output.append("## 🎯 Concluzii cluster")
    output.append("---")
    output.append("🔍 **Omogenitate:** Similaritatea între țări")
    output.append("💡 **Oportunități:** Potențial de dezvoltare")
    output.append("⚠️ **Provocări:** Puncte de îmbunătățit")
    
    return "\n".join(output)

# Încărcare dataset
if os.path.exists("chocolate_export_cleaned.csv"):
    # Dacă există deja un fișier curățat, îl încărcăm
    data_original = pd.read_csv("chocolate_export.csv", delimiter=';')
    data = pd.read_csv("chocolate_export_cleaned.csv", delimiter=',')
else:
    # Dacă nu există fișier curățat, încărcăm doar datele originale
    data_original = pd.read_csv("chocolate_export.csv", delimiter=';')
    data = data_original.copy()

# Creăm o copie pentru analiza valorilor lipsă
data_missing_analysis = data_original.copy()

# Adăugăm o nouă coloană "region" în funcție de country
region_mapping = {
    "Austria": "Europa Centrală", "Belgium": "Europa de Vest", "France": "Europa de Vest",
    "Germany": "Europa Centrală", "Italy": "Europa de Sud", "Netherlands": "Europa de Vest",
    "Poland": "Europa Centrală", "Spain": "Europa de Sud", "Sweden": "Europa de Nord",
    "Switzerland": "Europa de Vest", "Czech Republic": "Europa Centrală", "Hungary": "Europa Centrală",
    "Denmark": "Europa de Nord", "Norway": "Europa de Nord", "Finland": "Europa de Nord",
    "Portugal": "Europa de Sud", "Greece": "Europa de Sud", "Romania": "Europa de Est",
    "Bulgaria": "Europa de Est", "Slovakia": "Europa Centrală", "Slovenia": "Europa Centrală",
    "Estonia": "Europa de Nord", "Latvia": "Europa de Nord", "Lithuania": "Europa de Nord",
    "Croatia": "Europa Centrală", "Cyprus": "Europa de Sud", "Czechia": "Europa Centrală",
    "Ireland (Eire)": "Europa de Vest", "Luxembourg": "Europa de Vest", "Malta": "Europa de Sud"
}
data["region"] = data["country"].map(region_mapping)




# Meniuri
section = st.sidebar.radio("Navigați la:",
                           ["Introducere","Afișare dataset", "Tratarea valorilor extreme", "Grafice", "Codificarea datelor", "Scalare", "Geopandas", "Selecție și Filtrare",
                            "Statistici descriptive și interpretare", "Grupare și agregare", "Analiza de Regresie și Clusterizare"])






#1. Pagina Start
if section == "Introducere":
    st.title("📦 Proiect: Pachete Software")

    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .elegant-text {
            font-family: 'Italianno', cursive;
            font-size: 48px;
            color: #f0f0f0;
            text-align: center;
            line-height: 1.6;
        }
        </style>
        <div class="elegant-text">
            Analiza Exportului de Ciocolată în Europa
        </div>
        """, unsafe_allow_html=True)

    st.markdown(
        "<h3 style='text-align: center; color: white;'>🔹 Profesor coordonator: <b>Dobrița Gabriela</b></h3>",
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <style>
        .students-info {
            text-align: right;
            font-size: 16px;
            margin-right: 100px; 
            line-height: 1.8; 
            color: white;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <div class="students-info">
            <p>Studenți: Cozlov Petrișor-Georgian și Frîncu Luisa</p>
            <p>Grupa: 1091</p>
            <p>Seria: C</p>
        </div>
        """,
        unsafe_allow_html=True
    )







#2. Afișare dataset
elif section == "Afișare dataset":
    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .elegant-text {
            font-family: 'Italianno', cursive !important;
            font-size: 42px !important;
            color: #4CAF50 !important;
            margin-bottom: 10px !important;
            font-weight: 900 !important;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2) !important;
            line-height: 1 !important;
        }
        .description-text {
            color: #e0e0e0;
            font-size: 18px;
            margin: 15px 0;
            padding: 10px;
            border-left: 3px solid #4CAF50;
            background-color: rgba(76, 175, 80, 0.1);
        }
        .info-box {
            background-color: rgba(76, 175, 80, 0.1);
            border-left: 4px solid #4CAF50;
            padding: 15px;
            margin: 10px 0;
            color: #e0e0e0;
        }
        </style>
    """, unsafe_allow_html=True)

    st.header("📂 Vizualizare Set de Date")
    st.markdown('<p class="description-text">Explorează setul de date complet despre exportul de ciocolată în Europa, inclusiv toate înregistrările și variabilele disponibile.</p>', unsafe_allow_html=True)

    st.markdown('<p class="elegant-text">📊 Date Complete</p>', unsafe_allow_html=True)
    style_data = data_original
    st.dataframe(style_data)

    st.markdown('<p class="elegant-text">🔍 Verificare Calitate Date</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Analizăm prezența și tratarea valorilor lipsă din setul de date pentru a asigura calitatea analizei.</p>', unsafe_allow_html=True)

    num_missing = data_original.isnull().sum().sum()
    if num_missing > 0:
        st.warning(f"⚠️ S-au identificat {num_missing} valori lipsă în DataFrame.")
    else:
        st.success("✅ Nu există valori lipsă în DataFrame.")

    # Identificarea valorilor lipsă
    missing_values = data_original.isnull().sum().reset_index()
    missing_values.columns = ['Coloană', 'Numărul de valori lipsă']
    st.markdown('<p class="info-box">Numărul de valori lipsă per coloană:</p>', unsafe_allow_html=True)
    st.dataframe(missing_values)

    # Crearea unui nou dataset cu valorile tratate
    st.markdown('<p class="elegant-text">🛠️ Tratarea Valorilor Lipsă</p>', unsafe_allow_html=True)

    # Identificăm coloanele numerice
    numeric_columns = data.select_dtypes(include=['number']).columns

    # Creăm un DataFrame pentru a stoca informațiile despre înlocuiri
    replacement_info = []

    # Aplicăm metoda de tratare pentru fiecare coloană numerică
    for col in numeric_columns:
        if data[col].isnull().sum() > 0:
            median_val = data[col].median()
            num_missing = data[col].isnull().sum()
            data[col].fillna(median_val, inplace=True)
            replacement_info.append({
                'Coloană': col,
                'Număr valori lipsă': num_missing,
                'Valoare înlocuită': median_val
            })
            st.info(f"Valorile lipsă din coloana '{col}' au fost înlocuite cu mediana: {median_val:.2f}")

    # Afișăm un tabel cu toate înlocuirile făcute
    if replacement_info:
        st.markdown("""
            <div style='background-color: rgba(76, 175, 80, 0.2); border-left: 4px solid #4CAF50; padding: 15px; margin: 10px 0;'>
                <h3 style='color: #4CAF50; margin-bottom: 10px;'>📊 Rezumat al înlocuirilor efectuate:</h3>
                <p style='color: #e0e0e0;'>Iată toate valorile lipsă care au fost înlocuite:</p>
            </div>
        """, unsafe_allow_html=True)
        replacement_df = pd.DataFrame(replacement_info)
        st.dataframe(replacement_df)
    else:
        st.success("✅ Nu există valori lipsă care să necesite înlocuire.")

    # Documentăm metodele folosite
    st.markdown("""
        <div class="info-box">
            <h3>Metode de tratare aplicate:</h3>
            <ul>
                <li>Pentru coloanele numerice: Înlocuire cu mediana</li>
                <li>Motivație: Mediana este mai robustă la valori extreme decât media</li>
                <li>Coloane tratate: {}</li>
            </ul>
        </div>
    """.format(", ".join(numeric_columns)), unsafe_allow_html=True)

    # Salvăm noul dataset
    data.to_csv("chocolate_export_cleaned.csv", index=False)
    st.success("✅ Noul dataset cu valori tratate a fost salvat în 'chocolate_export_cleaned.csv'")

    # Afișăm noul dataset
    st.markdown('<p class="elegant-text">📊 Dataset Curățat</p>', unsafe_allow_html=True)
    st.dataframe(data)

    # Verificăm dacă mai există valori lipsă
    num_missing_after = data.isnull().sum().sum()
    if num_missing_after > 0:
        st.warning(f"⚠️ Au rămas {num_missing_after} valori lipsă în DataFrame.")
    else:
        st.success("✅ Toate valorile lipsă au fost tratate cu succes.")

    # Actualizăm variabila globală data pentru a folosi versiunea curățată în restul analizelor
    data = data

    st.markdown('<p class="elegant-text">📊 Vizualizare Valorilor Lipsă</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Graficul de mai jos arată distribuția valorilor lipsă pe coloane, oferind o perspectivă vizuală asupra datelor incomplete.</p>', unsafe_allow_html=True)

    # Vizualizarea valorilor lipsă
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(missing_values['Coloană'], missing_values['Numărul de valori lipsă'], color='#4CAF50')
    plt.title('Distribuția valorilor lipsă pe coloane')
    plt.xlabel('Coloane')
    plt.ylabel('Număr de valori lipsă')
    plt.xticks(rotation=45)
    plt.tight_layout()
    st.pyplot(fig)

    # Metode de tratare
    st.markdown('<p class="elegant-text">🛠️ Metode de tratare a valorilor lipsă</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Există mai multe abordări pentru tratarea valorilor lipsă. Iată cele mai comune metode:</p>', unsafe_allow_html=True)

    # Înlocuirea cu 0
    st.markdown("""
        <div style='background-color: rgba(76, 175, 80, 0.2); border-left: 4px solid #4CAF50; padding: 15px; margin: 10px 0;'>
            <h3 style='color: #4CAF50; margin-bottom: 10px;'>1. Înlocuirea cu 0</h3>
            <p style='color: #e0e0e0;'>Această metodă este potrivită când valorile lipsă reprezintă efectiv zero sau când nu avem informații suplimentare.</p>
            <div style='background-color: rgba(0, 0, 0, 0.2); padding: 10px; border-radius: 5px; margin-top: 10px;'>
                <code style='color: #4CAF50;'># Înlocuirea valorilor lipsă cu 0<br>data.fillna(0, inplace=True)</code>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Înlocuirea cu media
    st.markdown("""
        <div style='background-color: rgba(76, 175, 80, 0.2); border-left: 4px solid #4CAF50; padding: 15px; margin: 10px 0;'>
            <h3 style='color: #4CAF50; margin-bottom: 10px;'>2. Înlocuirea cu media</h3>
            <p style='color: #e0e0e0;'>Această metodă păstrează distribuția generală a datelor, dar poate introduce bias în analiză.</p>
            <div style='background-color: rgba(0, 0, 0, 0.2); padding: 10px; border-radius: 5px; margin-top: 10px;'>
                <code style='color: #4CAF50;'># Înlocuirea valorilor lipsă cu media coloanei<br>data['white_chocolate_t'].fillna(data['white_chocolate_t'].mean(), inplace=True)</code>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Înlocuirea cu mediana
    st.markdown("""
        <div style='background-color: rgba(76, 175, 80, 0.2); border-left: 4px solid #4CAF50; padding: 15px; margin: 10px 0;'>
            <h3 style='color: #4CAF50; margin-bottom: 10px;'>3. Înlocuirea cu mediana</h3>
            <p style='color: #e0e0e0;'>Mediana este mai robustă la valori extreme decât media.</p>
            <div style='background-color: rgba(0, 0, 0, 0.2); padding: 10px; border-radius: 5px; margin-top: 10px;'>
                <code style='color: #4CAF50;'># Înlocuirea valorilor lipsă cu mediana coloanei<br>data['white_chocolate_t'].fillna(data['white_chocolate_t'].median(), inplace=True)</code>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Implementare și verificare
    st.markdown('<p class="elegant-text">✅ Implementare și verificare</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Am aplicat metoda de înlocuire cu mediana pentru coloanele cu valori lipsă în datasetul original.</p>', unsafe_allow_html=True)

    st.markdown('<p class="info-box">Verificare după tratare:</p>', unsafe_allow_html=True)
    missing_values_after = data.isnull().sum().reset_index()
    missing_values_after.columns = ['Coloană', 'Numărul de valori lipsă']
    st.dataframe(missing_values_after)

    # Concluzii și recomandări
    st.markdown('<p class="elegant-text">💡 Concluzii și recomandări</p>', unsafe_allow_html=True)
    st.markdown("""
        <div class="info-box">
            <p>• Am identificat valori lipsă în coloanele legate de ciocolata albă</p>
            <p>• Am aplicat metoda de înlocuire cu mediana pentru aceste coloane în datasetul original</p>
            <p>• Am ales această metodă deoarece:</p>
            <ul>
                <li>Păstrează distribuția datelor</li>
                <li>Este robustă la valori extreme</li>
                <li>Este logică din punct de vedere al business-ului</li>
            </ul>
        </div>
    """, unsafe_allow_html=True)

    st.markdown('<p class="elegant-text">📊 Date Actualizate</p>', unsafe_allow_html=True)
    st.dataframe(data)






#3. Tratarea valorilor extreme
elif section == "Tratarea valorilor extreme":
    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .elegant-text {
            font-family: 'Italianno', cursive !important;
            font-size: 42px !important;
            color: #FF6B6B !important;
            margin-bottom: 10px !important;
            font-weight: 900 !important;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2) !important;
            line-height: 1 !important;
        }
        .description-text {
            color: #e0e0e0;
            font-size: 18px;
            margin: 15px 0;
            padding: 10px;
            border-left: 3px solid #FF6B6B;
            background-color: rgba(255, 107, 107, 0.1);
        }
        .info-box {
            background-color: rgba(255, 107, 107, 0.1);
            border-left: 4px solid #FF6B6B;
            padding: 15px;
            margin: 10px 0;
            color: #e0e0e0;
        }
        .method-box {
            background-color: rgba(255, 107, 107, 0.2);
            border-left: 4px solid #FF6B6B;
            padding: 15px;
            margin: 10px 0;
        }
        .method-title {
            color: #FF6B6B;
            font-size: 24px;
            margin-bottom: 10px;
        }
        .code-box {
            background-color: rgba(0, 0, 0, 0.3);
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
        }
        .code-text {
            color: #FFD93D;
        }
        .stats-box {
            background-color: rgba(255, 107, 107, 0.15);
            border-left: 4px solid #FF6B6B;
            padding: 15px;
            margin: 10px 0;
        }
        .stats-title {
            color: #FF6B6B;
            font-size: 20px;
            margin-bottom: 10px;
        }
        .stats-text {
            color: #e0e0e0;
        }
        </style>
    """, unsafe_allow_html=True)

    st.header("📊 Tratarea Valorilor Extreme")
    st.markdown('<p class="description-text">Analizăm și tratăm valorile extreme din setul de date pentru a îmbunătăți calitatea analizei statistice.</p>', unsafe_allow_html=True)

    # Identificarea valorilor extreme
    st.markdown('<p class="elegant-text">🔍 Identificarea Valorilor Extreme</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Folosim metoda IQR (Interquartile Range) pentru a identifica valorile extreme.</p>', unsafe_allow_html=True)

    # Selectăm coloanele numerice pentru analiză
    numeric_columns = [col for col in data.select_dtypes(include=['number']).columns if col != 'year']
    selected_column = st.selectbox("Selectează coloana pentru analiză:", numeric_columns)

    # Calculăm statisticile necesare
    Q1 = data[selected_column].quantile(0.25)
    Q3 = data[selected_column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    # Identificăm valorile extreme
    outliers = data[(data[selected_column] < lower_bound) | (data[selected_column] > upper_bound)]

    # Explicații specifice pentru fiecare coloană
    column_explanations = {
        'white_chocolate_t': {
            'description': 'Cantitatea de ciocolată albă exportată în tone',
            'interpretation': 'Valorile extreme pot indica țări cu producție neobișnuit de mare sau mică de ciocolată albă.',
            'calculation': 'IQR = Q3 - Q1, unde Q1 este a 25-a percentilă și Q3 este a 75-a percentilă din distribuția exporturilor de ciocolată albă.'
        },
        'white_chocolate_euro': {
            'description': 'Valoarea exporturilor de ciocolată albă în euro',
            'interpretation': 'Valorile extreme pot indica țări cu prețuri neobișnuit de mari sau mici pentru ciocolata albă.',
            'calculation': 'IQR = Q3 - Q1, unde Q1 este a 25-a percentilă și Q3 este a 75-a percentilă din distribuția valorilor în euro.'
        },
        'chocolate_t': {
            'description': 'Cantitatea totală de ciocolată exportată în tone',
            'interpretation': 'Valorile extreme pot indica țări cu volume neobișnuit de mari sau mici de export de ciocolată.',
            'calculation': 'IQR = Q3 - Q1, unde Q1 este a 25-a percentilă și Q3 este a 75-a percentilă din distribuția exporturilor totale.'
        },
        'chocolate_euro': {
            'description': 'Valoarea totală a exporturilor de ciocolată în euro',
            'interpretation': 'Valorile extreme pot indica țări cu valori neobișnuit de mari sau mici ale exporturilor în euro.',
            'calculation': 'IQR = Q3 - Q1, unde Q1 este a 25-a percentilă și Q3 este a 75-a percentilă din distribuția valorilor totale în euro.'
        }
    }

    st.markdown("""
        <div class="stats-box">
            <h3 class="stats-title">Statistici pentru identificarea valorilor extreme:</h3>
            <p class="stats-text">• Quartila 1 (Q1): {:.2f}</p>
            <p class="stats-text">• Quartila 3 (Q3): {:.2f}</p>
            <p class="stats-text">• IQR: {:.2f}</p>
            <p class="stats-text">• Limita inferioară: {:.2f}</p>
            <p class="stats-text">• Limita superioară: {:.2f}</p>
            <p class="stats-text">• Număr de valori extreme: {}</p>
        </div>
    """.format(Q1, Q3, IQR, lower_bound, upper_bound, len(outliers)), unsafe_allow_html=True)

    # Adăugăm explicațiile specifice pentru coloana selectată
    if selected_column in column_explanations:
        st.markdown("""
            <div style='background-color: rgba(255, 107, 107, 0.2); border-left: 4px solid #FF6B6B; padding: 20px; margin: 15px 0; border-radius: 5px;'>
                <h3 style='color: #FF6B6B; font-size: 24px; margin-bottom: 15px; text-shadow: 1px 1px 2px rgba(0,0,0,0.2);'>
                    📊 Explicații pentru {}
                </h3>
                <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin: 10px 0;'>
                    <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Descriere:</h4>
                    <p style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>{}</p>
                </div>
                <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin: 10px 0;'>
                    <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Interpretare:</h4>
                    <p style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>{}</p>
                </div>
                <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin: 10px 0;'>
                    <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Calculul IQR:</h4>
                    <p style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>{}</p>
                </div>
                <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin: 10px 0;'>
                    <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Limitele IQR:</h4>
                    <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                        <li>Limita inferioară = Q1 - 1.5 × IQR</li>
                        <li>Limita superioară = Q3 + 1.5 × IQR</li>
                    </ul>
                    <p style='color: #e0e0e0; font-size: 16px; line-height: 1.6; margin-top: 10px;'>
                        Valorile care se încadrează în afara acestor limite sunt considerate extreme.
                    </p>
                </div>
            </div>
        """.format(
            selected_column,
            column_explanations[selected_column]['description'],
            column_explanations[selected_column]['interpretation'],
            column_explanations[selected_column]['calculation']
        ), unsafe_allow_html=True)

    # Vizualizarea box plot
    st.markdown('<p class="elegant-text">📈 Vizualizare Box Plot</p>', unsafe_allow_html=True)
    st.markdown("""
        <div style='background-color: rgba(255, 107, 107, 0.2); border-left: 4px solid #FF6B6B; padding: 20px; margin: 15px 0; border-radius: 5px;'>
            <h3 style='color: #FF6B6B; font-size: 24px; margin-bottom: 15px; text-shadow: 1px 1px 2px rgba(0,0,0,0.2);'>
                📊 Interpretarea Box Plot-ului
            </h3>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Elementele Box Plot-ului:</h4>
                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                    <li><strong>Cutia (Box):</strong> Reprezintă intervalul interquartilic (IQR) - 50% din date</li>
                    <li><strong>Linia din mijloc:</strong> Mediana - împarte datele în două părți egale</li>
                    <li><strong>Mustățile (Whiskers):</strong> Se extind până la valorile extreme non-outlier</li>
                    <li><strong>Punctele:</strong> Reprezintă valorile extreme (outliers)</li>
                </ul>
            </div>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Cum să interpretezi:</h4>
                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                    <li><strong>Simetria:</strong> Dacă mediana este în mijlocul cutiei, datele sunt simetrice</li>
                    <li><strong>Asimetria:</strong> Dacă mediana este deplasată, datele sunt asimetrice</li>
                    <li><strong>Dispersia:</strong> Lungimea cutiei și a mustăților indică variabilitatea datelor</li>
                    <li><strong>Outliers:</strong> Punctele izolate indică valori neobișnuite sau extreme</li>
                </ul>
            </div>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Implicații pentru Analiza Datelor:</h4>
                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                    <li><strong>Distribuția:</strong> Oferă o imagine clară a distribuției datelor</li>
                    <li><strong>Valori Atipice:</strong> Ajută la identificarea valorilor care necesită investigații suplimentare</li>
                    <li><strong>Comparație:</strong> Permite compararea ușoară între diferite seturi de date</li>
                    <li><strong>Calitatea Datelor:</strong> Ajută la identificarea potențialelor erori sau anomalii în date</li>
                </ul>
            </div>
        </div>
    """, unsafe_allow_html=True)

    fig, ax = plt.subplots(figsize=(10, 6))
    data.boxplot(column=selected_column, ax=ax)
    plt.title(f'Box Plot pentru {selected_column}')
    plt.ylabel('Valori')
    st.pyplot(fig)

    # Adăugăm statistici specifice pentru boxplot
    Q1 = data[selected_column].quantile(0.25)
    Q3 = data[selected_column].quantile(0.75)
    IQR = Q3 - Q1
    median = data[selected_column].median()
    
    st.markdown(f"""
        <div style='background-color: rgba(255, 107, 107, 0.2); border-left: 4px solid #FF6B6B; padding: 20px; margin: 15px 0; border-radius: 5px;'>
            <h3 style='color: #FF6B6B; font-size: 24px; margin-bottom: 15px;'>
                📊 Statistici Box Plot
            </h3>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>Quartila 1 (Q1):</strong> {Q1:.2f}</p>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>Mediană:</strong> {median:.2f}</p>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>Quartila 3 (Q3):</strong> {Q3:.2f}</p>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>IQR:</strong> {IQR:.2f}</p>
            </div>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                <h4 style='color: #FFD93D; font-size: 20px; margin-bottom: 10px;'>Interpretare Statistică:</h4>
                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                    <li>50% din date se află între {Q1:.2f} și {Q3:.2f}</li>
                    <li>Valoarea mediană de {median:.2f} indică centrul distribuției</li>
                    <li>IQR de {IQR:.2f} arată dispersia centrală a datelor</li>
                    <li>{'Distribuția este asimetrică spre dreapta' if (Q3 - median) > (median - Q1) else 'Distribuția este asimetrică spre stânga' if (Q3 - median) < (median - Q1) else 'Distribuția este aproximativ simetrică'}</li>
                </ul>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Metode de tratare
    st.markdown('<p class="elegant-text">🛠️ Metode de Tratare</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Există mai multe abordări pentru tratarea valorilor extreme:</p>', unsafe_allow_html=True)

    # Metoda 1: Înlocuirea cu limitele IQR
    st.markdown("""
        <div class="method-box">
            <h3 class="method-title">1. Înlocuirea cu limitele IQR</h3>
            <p class="stats-text">Valorile extreme sunt înlocuite cu limitele calculate (lower_bound sau upper_bound).</p>
            <div class="code-box">
                <code class="code-text"># Înlocuirea valorilor extreme cu limitele IQR<br>
                data[selected_column] = data[selected_column].clip(lower_bound, upper_bound)</code>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Metoda 2: Înlocuirea cu mediana
    st.markdown("""
        <div class="method-box">
            <h3 class="method-title">2. Înlocuirea cu mediana</h3>
            <p class="stats-text">Valorile extreme sunt înlocuite cu mediana coloanei.</p>
            <div class="code-box">
                <code class="code-text"># Înlocuirea valorilor extreme cu mediana<br>
                median_value = data[selected_column].median()<br>
                data.loc[data[selected_column] < lower_bound, selected_column] = median_value<br>
                data.loc[data[selected_column] > upper_bound, selected_column] = median_value</code>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Metoda 3: Eliminarea valorilor extreme
    st.markdown("""
        <div class="method-box">
            <h3 class="method-title">3. Eliminarea valorilor extreme</h3>
            <p class="stats-text">Se elimină complet rândurile care conțin valori extreme.</p>
            <div class="code-box">
                <code class="code-text"># Eliminarea rândurilor cu valori extreme<br>
                data = data[(data[selected_column] >= lower_bound) & (data[selected_column] <= upper_bound)]</code>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Implementare și verificare
    st.markdown('<p class="elegant-text">✅ Implementare și Verificare</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Aplicăm metoda de tratare și verificăm rezultatele:</p>', unsafe_allow_html=True)

    # Creăm o copie a datelor pentru demonstrație
    demo_data = data.copy()

    # Aplicăm metoda de tratare (în acest caz, înlocuirea cu limitele IQR)
    demo_data[selected_column] = demo_data[selected_column].clip(lower_bound, upper_bound)

    # Afișăm statisticile înainte și după tratare
    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<p class="stats-box">Statistici înainte de tratare:</p>', unsafe_allow_html=True)
        st.write(data[selected_column].describe())

    with col2:
        st.markdown('<p class="stats-box">Statistici după tratare:</p>', unsafe_allow_html=True)
        st.write(demo_data[selected_column].describe())

    # Concluzii și recomandări
    st.markdown('<p class="elegant-text">💡 Concluzii și Recomandări</p>', unsafe_allow_html=True)
    st.markdown("""
        <div class="info-box">
            <p>• Am identificat {} valori extreme în coloana {}</p>
            <p>• Am demonstrat trei metode diferite de tratare a acestor valori</p>
            <p>• Pentru acest set de date, înlocuirea cu limitele IQR este recomandată deoarece:</p>
            <ul>
                <li>Păstrează structura datelor</li>
                <li>Este o metodă conservativă</li>
                <li>Nu pierde informații importante</li>
            </ul>
        </div>
    """.format(len(outliers), selected_column), unsafe_allow_html=True)






#4. Grafice
elif section == "Grafice":
    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .elegant-text {
            font-family: 'Italianno', cursive !important;
            font-size: 42px !important;
            color: #4CAF50 !important;
            margin-bottom: 10px !important;
            font-weight: 900 !important;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2) !important;
            line-height: 1 !important;
        }
        .description-text {
            color: #e0e0e0;
            font-size: 18px;
            margin: 15px 0;
            padding: 10px;
            border-left: 3px solid #4CAF50;
            background-color: rgba(76, 175, 80, 0.1);
        }
        .select-label {
            color: #4CAF50;
            font-size: 20px;
            font-weight: bold;
            margin: 5px 0;
        }
        </style>
    """, unsafe_allow_html=True)

    st.header("📈 Analiză Grafică")
    st.markdown('<p class="description-text">Vizualizează evoluția exportului de ciocolată în timp pentru diferite țări și variabile de interes.</p>', unsafe_allow_html=True)

    st.markdown('<p class="elegant-text">📊 Lineplot – Evoluția în timp</p>', unsafe_allow_html=True)
    st.markdown('<p class="description-text">Acest grafic arată tendințele și patternurile temporale ale exporturilor de ciocolată.</p>', unsafe_allow_html=True)

    st.markdown('<p class="select-label">🌍 Selectează țara:</p>', unsafe_allow_html=True)
    country_list = data["country"].unique().tolist()
    selected_country = st.selectbox("", country_list)

    st.markdown('<p class="select-label">🔢 Alege variabila de analizat:</p>', unsafe_allow_html=True)
    numeric_columns = [col for col in data.select_dtypes(include=['number']).columns if col != 'year']
    selected_col = st.selectbox(" ", numeric_columns)

    df_filtered = data[data["country"] == selected_country]

    fig, ax = plt.subplots()
    ax.plot(df_filtered["year"], df_filtered[selected_col], marker='o', linestyle='-', color='skyblue')
    ax.set_xlabel("Anul")
    ax.set_ylabel(selected_col)
    ax.set_title(f"Evoluția {selected_col} pentru {selected_country}")
    ax.set_xticks(df_filtered["year"])
    st.pyplot(fig)

    # Adăugăm interpretarea graficului
    st.markdown("""
        <div style='background-color: rgba(76, 175, 80, 0.1); border-left: 4px solid #4CAF50; padding: 20px; margin: 15px 0; border-radius: 5px;'>
            <h3 style='color: #4CAF50; font-size: 24px; margin-bottom: 15px;'>
                📊 Interpretarea Graficului
            </h3>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Analiza Tendințelor:</h4>
                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                    <li><strong>Evoluție temporală:</strong> Graficul arată cum s-au schimbat valorile de-a lungul anilor pentru țara selectată</li>
                    <li><strong>Puncte de inflexiune:</strong> Punctele de pe grafic marchează momentele exacte de măsurare</li>
                    <li><strong>Tendința generală:</strong> Linia continuă ajută la identificarea pattern-ului general (crescător/descrescător)</li>
                </ul>
            </div>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Cum să interpretezi:</h4>
                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                    <li><strong>Creștere:</strong> Liniile ascendente indică o creștere a valorilor în timp</li>
                    <li><strong>Scădere:</strong> Liniile descendente indică o scădere a valorilor în timp</li>
                    <li><strong>Stabilitate:</strong> Liniile orizontale indică valori constante</li>
                    <li><strong>Fluctuații:</strong> Variațiile frecvente indică instabilitate sau sezonalitate</li>
                </ul>
            </div>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Implicații pentru Business:</h4>
                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                    <li><strong>Performanță:</strong> Identifică perioadele de performanță ridicată sau scăzută</li>
                    <li><strong>Oportunități:</strong> Evidențiază potențiale oportunități de creștere</li>
                    <li><strong>Riscuri:</strong> Ajută la identificarea perioadelor problematice</li>
                    <li><strong>Planificare:</strong> Oferă informații pentru planificarea strategică viitoare</li>
                </ul>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Adăugăm statistici descriptive pentru seria temporală
    stats_df = df_filtered[selected_col].describe()
    st.markdown("""
        <div style='background-color: rgba(76, 175, 80, 0.1); border-left: 4px solid #4CAF50; padding: 20px; margin: 15px 0; border-radius: 5px;'>
            <h3 style='color: #4CAF50; font-size: 24px; margin-bottom: 15px;'>
                📈 Statistici Descriptive
            </h3>
            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>Valoare medie:</strong> {:.2f}</p>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>Valoare minimă:</strong> {:.2f}</p>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>Valoare maximă:</strong> {:.2f}</p>
                <p style='color: #e0e0e0; font-size: 16px;'><strong>Deviație standard:</strong> {:.2f}</p>
            </div>
        </div>
    """.format(
        stats_df['mean'],
        stats_df['min'],
        stats_df['max'],
        stats_df['std']
    ), unsafe_allow_html=True)

    # Calculăm și afișăm rata de creștere
    if len(df_filtered[selected_col]) >= 2:
        first_value = df_filtered[selected_col].iloc[0]
        last_value = df_filtered[selected_col].iloc[-1]
        growth_rate = ((last_value - first_value) / first_value) * 100 if first_value != 0 else 0
        
        st.markdown(f"""
            <div style='background-color: rgba(76, 175, 80, 0.1); border-left: 4px solid #4CAF50; padding: 20px; margin: 15px 0; border-radius: 5px;'>
                <h3 style='color: #4CAF50; font-size: 24px; margin-bottom: 15px;'>
                    📊 Analiza Creșterii
                </h3>
                <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                    <p style='color: #e0e0e0; font-size: 16px;'><strong>Rata totală de creștere:</strong> {growth_rate:.2f}%</p>
                    <p style='color: #e0e0e0; font-size: 16px;'><strong>Valoare inițială:</strong> {first_value:.2f}</p>
                    <p style='color: #e0e0e0; font-size: 16px;'><strong>Valoare finală:</strong> {last_value:.2f}</p>
                </div>
                <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                    <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Interpretare:</h4>
                    <p style='color: #e0e0e0; font-size: 16px;'>
                        {'Creștere semnificativă' if growth_rate > 50 else 'Creștere moderată' if growth_rate > 0 else 'Scădere'} în perioada analizată.
                        {
                            'Acest lucru indică o performanță foarte bună și o expansiune puternică a exporturilor.' if growth_rate > 50
                            else 'Acest lucru indică o evoluție pozitivă stabilă.' if growth_rate > 0
                            else 'Acest lucru poate indica provocări în sectorul de export.'
                        }
                    </p>
                </div>
            </div>
        """, unsafe_allow_html=True)






#5.  Codificarea datelor
elif section == "Codificarea datelor":
    st.header("🔢  Codificarea datelor categoriale")

    st.markdown("""
        În această secțiune demonstrăm modul în care se pot transforma variabilele de tip categoric
        (cum este `region`) în variabile numerice, care pot fi ulterior folosite în modele de tip `regresie` sau `clusterizare`.
    """)

    st.subheader("🧪 Codificare binară: Europa de Vest vs restul")
    coded_data = data.copy()
    coded_data["is_western"] = (coded_data["region"] == "Europa de Vest").astype(int)
    st.dataframe(coded_data[["country", "region", "is_western"]])
    st.markdown("""
        Am adăugat o coloană binară `is_western`, unde valoarea este `1` pentru țările din Europa de Vest
        și `0` pentru restul.
    """)
    # Salvăm în CSV
    coded_data.to_csv("coded_data.csv", index=False, encoding='utf-8-sig')


    st.subheader("🧾 Codificare one-hot:")
    region_dummies = pd.get_dummies(coded_data["region"], prefix="region", drop_first=True)
    coded_data = pd.concat([coded_data, region_dummies], axis=1)
    st.dataframe(coded_data[["country", "region"]+list(region_dummies.columns)])

    st.markdown("""
        **🔍 Observație:** Pentru a evita multicoliniaritatea (colinearitate perfectă) în modele statistice 
        sau regresii am folosit `drop_first=Tru` care omite *Europa Centrală*, ea devenind astfel referință.
        
        Fiecare coloană indică apartenența unei țări la o regiune. 
        Valoarea `1` înseamnă că țara aparține regiunii respective, `0` altfel. 
        Regiunea *Europa Centrală* a fost omisă și servește drept referință. 
    """)






#6. Scalare
elif section == "Scalare":
    st.header("⚖️ Scalarea datelor")

    st.markdown("""
    În această secțiune, standardizăm variabilele numerice astfel încât să aibă media 0 și abaterea standard 1.  
    Acest lucru este esențial pentru algoritmi sensibili la scări diferite ale variabilelor (ex: regresie, k-means).
    """)

    # Selectăm doar coloanele numerice pentru scalare
    numeric_cols = data.select_dtypes(include='number').columns.tolist()
    if 'year' in numeric_cols:
        numeric_cols.remove('year')
    st.write("🔢 Coloane selectate pentru scalare:", numeric_cols)

    # Aplicăm StandardScaler
    scaler = StandardScaler()
    scaled_data = data.copy()
    scaled_data[numeric_cols] = scaler.fit_transform(data[numeric_cols])

    # Afișăm primele 5 rânduri din datele scalate
    st.subheader("📊 Date scalate:")
    st.dataframe(scaled_data)

    # Afișăm media și abaterea standard pentru fiecare coloană scalată
    st.subheader("📌 Statistici după scalare (media ≈ 0, abatere std ≈ 1):")
    for col in numeric_cols:
            st.write(f"**{col}** – Media: {scaled_data[col].mean():.4f}, Std: {scaled_data[col].std():.4f}")

    # Salvăm și oferim descărcare CSV
    csv_scaled = scaled_data.to_csv(index=False, encoding='utf-8-sig')
    scaled_data.to_csv ("scaled_data.csv")
    st.subheader("📊 Histograme pentru variabilele scalate")

    selected_column = st.selectbox("Alege o coloană numerică:", numeric_cols)

    fig, ax = plt.subplots()
    ax.hist(scaled_data[selected_column], bins=30, edgecolor='black')
    ax.set_title(f"Distribuția variabilei '{selected_column}' după scalare")
    ax.set_xlabel("Valoare scalată")
    ax.set_ylabel("Frecvență")

    st.pyplot(fig)

    st.subheader("📊 Interpretări Grafic:")
    st.markdown('''
    1. Distribuția este asimetrică spre dreapta (right-skewed).
    2. Majoritatea țărilor au exporturi **sub medie** , iar câteva țări exportă valori mult mai mari,
    ceea ce trage media în sus, sugerând că există o concentrare a exportului în câteva țări (ex. Belgia și Germania - tabel),
    în timp ce celelalte contribuie modest.
    
    
    
    ''')

#7. Geopandas
elif section == "Geopandas":
    st.header("🗺️🌍 Exporturi de ciocolată în Europa")

    # Încărcăm geometria țărilor
    world = gpd.read_file("Geopandas/ne_110m_admin_0_countries.shp")
    europe = world[world['CONTINENT'] == 'Europe']

    # Reunim datele cu țările
    merged = europe.merge(data, how="left", left_on="ADMIN", right_on="country")

    # Selectăm variabilele numerice
    numeric_cols = data.select_dtypes(include='number').columns.tolist()
    if "year" in numeric_cols:
        numeric_cols.remove("year")

    #Selectare variabila
    selected_col = st.selectbox("🔢 Alege o variabilă numerică de afișat pe hartă:", numeric_cols)

    # Desenăm harta
    fig, ax = plt.subplots(figsize=(10, 10))
    merged.boundary.plot(ax=ax, linewidth=0.8, color="black")  # contururi țări
    merged.plot(column=selected_col, ax=ax, legend=True, cmap="Blues", missing_kwds={
        "color": "lightgrey",
        "label": "Fără date"
    })

    # Zoom pe Europa continentală
    ax.set_xlim([-25, 45])   # longitudini
    ax.set_ylim([34, 72])    # latitudini

    ax.set_title(f" Distribuția '{selected_col}' în Europa", fontsize=15)
    ax.axis("off")

    st.pyplot(fig)







#8. Selecție și Filtrare
elif section == "Selecție și Filtrare":
    st.header("🔍 **Selecția & Filtrarea Datelor** | 📈 **Manipularea Datelor cu Pandas** 🐍")
    st.write("✨***Selectarea primelor două rânduri folosind slicing:***")
    st.code("data[:2]", language="python")
    st.write(data[:2])
    st.write("✨***Selectarea coloanei 'white_chocolate_t' folosind parantezele pătrate:***")
    st.code("data['white_chocolate_t']", language="python")
    st.write(data['white_chocolate_t'])
    st.write("✨***Selectarea rândurilor după poziție cu `.iloc[]` (al doilea și al zecelea rând):***")
    st.code("data.iloc[[1, 9]]", language="python")
    st.write(data.iloc[[1, 9]])
    st.markdown("""
        <h3 style='background-color: #28a745; color: white; padding: 10px;'>✅ Filtrarea rândurilor după condiții</h3>
        """, unsafe_allow_html=True)
    st.write("✨***Filtrați rândurile unde 'chocolate_t' este mai mare sau egală cu 144217.66:***")
    st.code("data[data['chocolate_t'] >= 144217.66]", language="python")
    data['chocolate_t'] = pd.to_numeric(data['chocolate_t'], errors='coerce')
    st.write(data[data['chocolate_t'] >= 144217.66])

    st.markdown("""
        <h3 style='background-color: #28a745; color: white; padding: 10px;'>✅ Actualizări cu loc</h3>
        """, unsafe_allow_html=True)

    st.write("""
            *✨ Se va aplica o reducere de 10% asupra valorilor din coloana `chocolate_euro` 
            pentru țările cu exporturi de ciocolată de peste 2.000.000 tone, 
            iar în paralel va fi creată o coloană suplimentară, `chocolate_euro_reduced`,
             care va conține valorile ajustate rezultate din această reducere.*✨**
            """)

    data['chocolate_euro_reduced'] = data['chocolate_euro']
    discount_condition = data['chocolate_t'] > 2000000
    data.loc[discount_condition, 'chocolate_euro_reduced'] = data.loc[discount_condition, 'chocolate_euro'] * 0.9
    st.code("""
    discount_condition = data['chocolate_t'] > 2000000
    data.loc[discount_condition, 'chocolate_euro_reduced'] = data.loc[discount_condition, 'chocolate_euro'] * 0.9
        """, language="python")
    st.write("***📊DataFrame după actualizarea reducerii:***")
    st.write(data)

    st.markdown("---")
    st.header("***Exemple cu loc și iloc***")

    st.markdown("""
        <h3 style='background-color: #28a745; color: white; padding: 10px;'>✅ Exemple cu loc</h3>
        """, unsafe_allow_html=True)

    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .elegant-subtitle {
            font-family: 'Italianno', cursive;
            color: #004d00;
            font-size: 28px !important;
            line-height: 1.4;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
            margin: 10px 0;
            font-weight: 900;
            padding: 10px;
            display: block;
            letter-spacing: 0.5px;
        }
        </style>
        <p class="elegant-subtitle">1. Filtrare și Selectarea Coloanelor Specifice:</p>
        """, unsafe_allow_html=True)

    filtered_df = data.loc[data['chocolate_t'] < 100000, ['country', 'year']]
    st.code("""
    filtered_df = data.loc[data['chocolate_t'] < 100000, ['country', 'year']]
        """, language="python")
    st.write("Afișarea țărilor și a anilor unde exportul de ciocolată este sub 100.000 tone.")
    st.write(filtered_df)

    st.markdown("""
        <p class="elegant-subtitle">2. Actualizarea mai multor coloane pe bază de condiție:</p>
        """, unsafe_allow_html=True)
    st.write(
        "Aplicarea unei valoari fixe pentru `chocolate_euro`"
        " și adăugarea unei coloane `Promo` pentru țările cu export sub 100.000 tone.")
    df_update = data.copy()
    promo_condition = df_update['chocolate_t'] < 100000
    df_update.loc[promo_condition, 'chocolate_euro'] = 99999
    df_update.loc[promo_condition, 'Promo'] = True
    st.code("""
    promo_condition = df_update['chocolate_t'] < 100000
    df_update.loc[promo_condition, 'chocolate_euro'] = 99999
    df_update.loc[promo_condition, 'Promo'] = True
        """, language="python")
    st.write("DataFrame după aplicarea reducerii promo (pentru rândurile unde chocolate_t este sub 100.000 tone.):")
    st.write(df_update)

    st.markdown("""
        <h3 style='background-color: #28a745; color: white; padding: 10px;'>✅ Exemple cu iloc</h3>
        """, unsafe_allow_html=True)

    st.markdown("""
        <p class="elegant-subtitle">1. Selectarea unui bloc de rânduri și coloane:</p>
        """, unsafe_allow_html=True)
    block_df = data.iloc[1:3, 0:2]  # Selectează rândurile 1 până la 2 și coloanele 0 până la 1.
    st.code("""
    block_df = data.iloc[1:3, 0:2]
        """, language="python")
    st.write("Bloc de date (rândurile 1-2, coloanele 0-1):")
    st.write(block_df)

    st.markdown("""
        <p class="elegant-subtitle">2. Selectarea rândurilor și coloanelor Non-Consecutive:</p>
        """, unsafe_allow_html=True)
    selected_df = data.iloc[[0, 3], [0, 2]]  # Primul și al patrulea rând, prima și a treia coloană.
    st.code("""
    selected_df = data.iloc[[0, 3], [0, 2]]
        """, language="python")
    st.write("Rânduri și coloane non-consecutive:")
    st.write(selected_df)






#9. Statistici descriptive și interpretare
elif section == "Statistici descriptive și interpretare":
    st.header("📊 Statistici Descriptive și Interpretare")

    # Calculam statisticile descriptive pentru datasetul numeric
    # Exclude coloana "year" din calculul statisticilor
    stats = data.drop(columns=['year']).describe().round(2)

    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .colored-header {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .elegant-text {
            font-family: 'Italianno', cursive !important;
            font-size: 42px !important;
            color: #4CAF50 !important;
            margin-bottom: 10px !important;
            font-weight: 900 !important;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2) !important;
            line-height: 1 !important;
        }
        .elegant-subtitle {
            font-family: 'Italianno', cursive !important;
            font-size: 36px !important;
            color: #4CAF50 !important;
            margin: 10px 0 !important;
            font-weight: 700 !important;
        }
        .normal-text {
            font-family: sans-serif;
            font-size: 16px;
            color: white;
            white-space: pre;
            margin-left: 20px;
            margin-bottom: 20px;
        }
        </style>
        """, unsafe_allow_html=True)

    st.markdown('<h3 class="colored-header">📈 Statistici Descriptive pentru setul de date</h3>', unsafe_allow_html=True)
    st.write("")  # Spațiu după titlu
    style_data = stats
    st.dataframe(style_data)

    st.markdown('<h3 class="colored-header">🔍 Interpretarea Statisticilor Descriptive</h3>', unsafe_allow_html=True)
    st.write("")  # Spațiu după titlu

    # Secțiunea 1
    st.markdown('<p class="elegant-text">1. 📊 Număr de observații (count):</p>', unsafe_allow_html=True)
    st.markdown("""<p class="normal-text">- Avem 135 de înregistrări pentru chocolate_euro și chocolate_t
- Pentru white_chocolate_euro și white_chocolate_t avem 127 de înregistrări, ceea ce indică că lipsesc 8 observații</p>""", unsafe_allow_html=True)

    # Secțiunea 2
    st.markdown('<p class="elegant-text">2. 📈 Media (mean):</p>', unsafe_allow_html=True)
    st.markdown("""<p class="normal-text">- Media exporturilor de ciocolată este de aproximativ 47,546.08 tone
- Valoarea medie a exporturilor în euro este de aproximativ 27,211,865 €
- Pentru ciocolata albă, media exporturilor este de aproximativ 1,958.21 tone, cu o valoare medie de 10,468,757 €</p>""", unsafe_allow_html=True)

    # Secțiunea 3
    st.markdown('<p class="elegant-text">3. 📊 Deviația standard (std):</p>', unsafe_allow_html=True)
    st.markdown("""<p class="normal-text">- Deviația standard pentru exporturile de ciocolată este de 73,936.01 tone
- Pentru exporturile în euro, deviația standard este de 443,755,781 €
- Pentru ciocolata albă, deviația standard este de 5,235.31 tone și 26,766,429 € respectiv
- Valorile mari ale deviației standard indică o variabilitate foarte mare în date</p>""", unsafe_allow_html=True)

    # Secțiunea 4
    st.markdown('<p class="elegant-text">4. ⬇️ Valori minime (min):</p>', unsafe_allow_html=True)
    st.markdown("""<p class="normal-text">- Cel mai mic export de ciocolată a fost de 57.92 tone
- Valoarea minimă pentru exportul de ciocolată albă este de 0.01 tone
- Valorile minime în euro sunt de 244,744 € pentru ciocolată și 180 € pentru ciocolată albă</p>""", unsafe_allow_html=True)

    # Secțiunea 5
    st.markdown('<p class="elegant-text">5. 📉 Percentile:</p>', unsafe_allow_html=True)
    st.markdown("""<p class="normal-text">- 25% din exporturile de ciocolată sunt sub 2,638.98 tone
- Mediana (50%) este de 12,977.19 tone
- 75% din exporturi sunt sub 59,638.18 tone
- Pentru ciocolata albă, quartilele sunt: Q1=28.83 tone, Q2=147.66 tone, Q3=1,093.18 tone </p>""", unsafe_allow_html=True)

    # Secțiunea 6
    st.markdown('<p class="elegant-text">6. ⬆️ Valori maxime (max):</p>', unsafe_allow_html=True)
    st.markdown("""<p class="normal-text">- Cel mai mare export de ciocolată a fost de 287,702.26 tone
- Pentru ciocolata albă, maximul a fost de 29.299.09 tone
- Valorile maxime în euro au fost de 206,191,265 € pentru ciocolată și 192,003,625 € pentru ciocolată albă</p>""", unsafe_allow_html=True)

    st.markdown('<h3 class="colored-header">💡 Concluzie:</h3>', unsafe_allow_html=True)
    st.info("""Datele arată o distribuție foarte neuniformă a exporturilor, cu diferențe mari între valorile minime și maxime. 
        Diferența semnificativă între medie și mediană (de exemplu, pentru ciocolată: medie ≈ 47,546.08 tone vs mediană ≈ 12,977.19 tone) 
        indică o distribuție puternic asimetrică spre dreapta (skewed right). Acest lucru sugerează că există câteva țări cu 
        volume foarte mari de export care influențează media, în timp ce majoritatea țărilor au exporturi mai modeste.""")






#7. Grupare și agregare
elif section == "Grupare și agregare":
    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .description-text {
            color: #e0e0e0;
            font-size: 18px;
            margin: 15px 0;
            padding: 10px;
            border-left: 3px solid #4CAF50;
            background-color: rgba(76, 175, 80, 0.1);
        }
        .select-label {
            color: #4CAF50;
            font-size: 20px;
            font-weight: bold;
            margin: 5px 0;
        }
        </style>
    """, unsafe_allow_html=True)

    st.header("📊 Grupare și Agregare")
    st.markdown('<p class="description-text">Explorează datele despre exportul de ciocolată folosind diferite metode de grupare și agregare pentru a descoperi tendințe și pattern-uri interesante.</p>', unsafe_allow_html=True)

    st.markdown('<p class="select-label">🔍 Alege metoda de analiză:</p>', unsafe_allow_html=True)
    option = st.radio("", ["Grupare simplă", "Grupare cu Agregare"])

    if option == "Grupare simplă":
        st.markdown('<p class="elegant-text">1. 📈 Grupare după o variabilă</p>', unsafe_allow_html=True)
        st.markdown('<p class="description-text">Această metodă ne permite să vedem distribuția datelor în funcție de o singură variabilă, oferind o perspectivă clară asupra frecvenței înregistrărilor.</p>', unsafe_allow_html=True)

        st.markdown('<p class="select-label">🎯 Alege variabila de grupare:</p>', unsafe_allow_html=True)
        v_grupare = st.selectbox("", ["region", "year", "country"])

        grouped_data = data.groupby(v_grupare).size().reset_index(name="număr înregistrări")
        st.markdown('<p class="elegant-subtitle">📊 Distribuția datelor grupate:</p>', unsafe_allow_html=True)
        style_data = grouped_data
        st.dataframe(style_data)

    elif option == "Grupare cu Agregare":
        st.markdown('<p class="elegant-text">1. 📊 Agregare pe o variabilă</p>', unsafe_allow_html=True)
        st.markdown('<p class="description-text">Această metodă combină gruparea cu funcții de agregare pentru a calcula statistici specifice pentru fiecare grup de date.</p>', unsafe_allow_html=True)

        st.markdown('<p class="select-label">🎯 Alege variabila de grupare:</p>', unsafe_allow_html=True)
        v_grupare = st.selectbox("", ["region", "year", "country"])

        st.markdown('<p class="select-label">📊 Selectează funcția de agregare:</p>', unsafe_allow_html=True)
        aggregation_function = st.selectbox(" ", ["sum", "mean", "max"])

        aggregated_data = data.groupby(v_grupare).agg({
            "white_chocolate_euro": aggregation_function,
            "white_chocolate_t": aggregation_function,
            "chocolate_euro": aggregation_function,
            "chocolate_t": aggregation_function
        }).round(2).reset_index()

        st.markdown('<p class="elegant-text">2. 📈 Rezultatele agregare</p>', unsafe_allow_html=True)
        st.markdown('<p class="description-text">Rezultatele agregate arată valorile calculate pentru fiecare grup folosind funcția de agregare selectată.</p>', unsafe_allow_html=True)
        st.markdown('<p class="elegant-subtitle">📊 Tabel agregat:</p>', unsafe_allow_html=True)
        style_data = aggregated_data
        st.dataframe(style_data)

        st.markdown('<p class="elegant-text">3. 📉 Vizualizare grafică</p>', unsafe_allow_html=True)
        st.markdown('<p class="description-text">Reprezentarea grafică sub formă de pie chart oferă o perspectivă vizuală asupra distribuției datelor agregate.</p>', unsafe_allow_html=True)

        st.markdown('<p class="select-label">🎯 Alege variabila pentru grafic:</p>', unsafe_allow_html=True)
        v_graf = st.selectbox("  ", ["white_chocolate_euro", "white_chocolate_t", "chocolate_euro", "chocolate_t"])

        fig, ax = plt.subplots()
        ax.pie(aggregated_data[v_graf].fillna(0), labels=aggregated_data[v_grupare], autopct='%1.1f%%', startangle=90)
        ax.set_title(f"Distribuția {v_graf} după {v_grupare}")
        st.pyplot(fig)






#10. Analiza de Regresie și Clusterizare
elif section == "Analiza de Regresie și Clusterizare":
    st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Italianno&display=swap');
        .elegant-text {
            font-family: 'Italianno', cursive !important;
            font-size: 42px !important;
            color: #4CAF50 !important;
            margin-bottom: 10px !important;
            font-weight: 900 !important;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2) !important;
            line-height: 1 !important;
        }
        .description-text {
            color: #e0e0e0;
            font-size: 18px;
            margin: 15px 0;
            padding: 10px;
            border-left: 3px solid #4CAF50;
            background-color: rgba(76, 175, 80, 0.1);
        }
        .select-label {
            color: #4CAF50;
            font-size: 20px;
            font-weight: bold;
            margin: 5px 0;
        }
        .info-box {
            background-color: rgba(76, 175, 80, 0.1);
            border-left: 4px solid #4CAF50;
            padding: 15px;
            margin: 10px 0;
            color: #e0e0e0;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .method-box {
            background-color: rgba(76, 175, 80, 0.2);
            border-left: 4px solid #4CAF50;
            padding: 15px;
            margin: 10px 0;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .method-title {
            color: #4CAF50;
            font-size: 24px;
            margin-bottom: 10px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }
        .highlight-box {
            background-color: rgba(76, 175, 80, 0.3);
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
            border: 2px solid #4CAF50;
        }
        .formula-box {
            background-color: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
            border: 1px solid #4CAF50;
        }
        .formula-text {
            color: #FFD93D;
            font-family: 'Times New Roman', serif;
            font-size: 18px;
        }
        </style>
    """, unsafe_allow_html=True)

    st.header("📊 Analiza de Regresie și Clusterizare")
    st.markdown("""
        <div class="description-text">
            <h3>🌟 Bine ați venit în secțiunea de analiză avansată! 🌟</h3>
            <p>Aici veți găsi instrumente puternice pentru a descoperi relații și pattern-uri în datele despre exportul de ciocolată.</p>
            <p>Puteți alege între:</p>
            <ul>
                <li><strong>Regresie simplă:</strong> Analizează relația dintre două variabile (ex: cum influențează cantitatea de ciocolată albă exportată valoarea totală a exporturilor)</li>
                <li><strong>Regresie multiplă:</strong> Analizează cum mai multe factori influențează împreună o variabilă (ex: cum afectează atât cantitatea cât și prețul exporturile totale)</li>
                <li><strong>Regresie logistică:</strong> Clasifică țările în două categorii bazate pe nivelul exporturilor (ex: exporturi mari vs mici)</li>
                <li><strong>Clusterizare:</strong> Identifică grupe naturale de țări cu comportamente similare în ceea ce privește exporturile</li>
            </ul>
        </div>
    """, unsafe_allow_html=True)

    # Selectarea tipului de analiză
    analysis_type = st.radio("Selectează tipul de analiză:", 
                            ["Regresie simplă", "Regresie multiplă", "Regresie logistică", "Clusterizare"])

    if analysis_type == "Regresie simplă":
        st.markdown("""
            <div class="method-box">
                <h3 class="method-title">📈 Regresie Simplă</h3>
                <p>Regresia simplă ne ajută să înțelegem cum o variabilă influențează alta. De exemplu:</p>
                <ul>
                    <li>Cum afectează cantitatea de ciocolată albă exportată valoarea totală a exporturilor?</li>
                    <li>Există o relație între cantitatea și valoarea exporturilor?</li>
                </ul>
                <div class="formula-box">
                    <p class="formula-text">Modelul matematic: y = α + βX + ε</p>
                    <p>Unde:</p>
                    <ul>
                        <li>y: variabila dependentă (ex: valoarea exporturilor)</li>
                        <li>X: variabila independentă (ex: cantitatea exportată)</li>
                        <li>α (intercept): valoarea lui y când X = 0</li>
                        <li>β (coeficient): cât de mult se schimbă y când X crește cu 1</li>
                        <li>ε: eroarea aleatorie</li>
                    </ul>
                </div>
                <div class="highlight-box">
                    <p><strong>💡 Sfaturi pentru interpretare:</strong></p>
                    <ul>
                        <li>Coeficientul de determinare (R²) arată cât de bine modelul explică variația datelor</li>
                        <li>Coeficientul de regresie (β) ne spune direcția și puterea relației</li>
                        <li>Interceptul (α) ne oferă valoarea de bază când X = 0</li>
                    </ul>
                </div>
            </div>
        """, unsafe_allow_html=True)

        # Selectarea variabilelor
        numeric_columns = data.select_dtypes(include=['number']).columns
        st.markdown('<p class="select-label">🎯 Selectează variabilele pentru regresie:</p>', unsafe_allow_html=True)
        col1, col2 = st.columns(2)
        
        with col1:
            X_var = st.selectbox("Variabilă independentă (X):", numeric_columns)
        with col2:
            y_var = st.selectbox("Variabilă dependentă (y):", numeric_columns)

        # Pregătirea datelor
        X = data[X_var].values.reshape(-1, 1)
        y = data[y_var].values

        # Crearea și antrenarea modelului
        model = LinearRegression()
        model.fit(X, y)

        # Calcularea predicțiilor și metricilor
        y_pred = model.predict(X)
        r2_score = model.score(X, y)

        # Afișarea rezultatelor
        st.markdown('<p class="elegant-text">📊 Rezultatele Regresiei</p>', unsafe_allow_html=True)
        st.markdown(f"""
            <div class="info-box">
                <h3>Metrici de Performanță:</h3>
                <p>• Coeficientul de determinare (R²): {r2_score:.4f}</p>
                <p>• Coeficientul de regresie (β): {model.coef_[0]:.4f}</p>
                <p>• Interceptul (α): {model.intercept_:.4f}</p>
                <div class="highlight-box">
                    <p><strong>Interpretare:</strong></p>
                    <ul>
                        <li>Pentru fiecare unitate de creștere în {X_var}, {y_var} se modifică cu {model.coef_[0]:.4f} unități</li>
                        <li>Modelul explică {r2_score*100:.1f}% din variația în {y_var}</li>
                        <li>Valoarea de bază (când {X_var} = 0) este {model.intercept_:.4f}</li>
                    </ul>
                </div>
            </div>
        """, unsafe_allow_html=True)

        # Vizualizarea regresiei
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.scatter(X, y, color='blue', alpha=0.5, label='Date reale')
        ax.plot(X, y_pred, color='red', label='Linia de regresie')
        ax.set_xlabel(X_var)
        ax.set_ylabel(y_var)
        ax.set_title(f'Regresie simplă: {y_var} vs {X_var}')
        ax.legend()
        plt.grid(True, alpha=0.3)
        st.pyplot(fig)

        # Adăugăm analiza reziduurilor
        st.markdown('<p class="elegant-text">🔍 Analiza Reziduurilor</p>', unsafe_allow_html=True)
        residuals = y - y_pred
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
        
        # Graficul reziduurilor vs valori prezise
        ax1.scatter(y_pred, residuals, alpha=0.5)
        ax1.axhline(y=0, color='r', linestyle='--')
        ax1.set_xlabel('Valori prezise')
        ax1.set_ylabel('Reziduuri')
        ax1.set_title('Graficul reziduurilor')
        ax1.grid(True, alpha=0.3)
        
        # Histograma reziduurilor
        ax2.hist(residuals, bins=30, alpha=0.7)
        ax2.set_xlabel('Reziduuri')
        ax2.set_ylabel('Frecvență')
        ax2.set_title('Distribuția reziduurilor')
        ax2.grid(True, alpha=0.3)
        
        st.pyplot(fig)

        # Testul de normalitate a reziduurilor
        _, p_value = stats.shapiro(residuals)
        st.markdown(f"""
            <div class="info-box">
                <h3>Testul de Normalitate a Reziduurilor (Shapiro-Wilk):</h3>
                <p>• p-value: {p_value:.4f}</p>
                <p>• Interpretare: {"Reziduurile par a urma o distribuție normală" if p_value > 0.05 else "Reziduurile nu urmează o distribuție normală"}</p>
                <div class="highlight-box">
                    <p><strong>Explicație:</strong></p>
                    <ul>
                        <li>Folosim testul Shapiro-Wilk pentru verificarea normalității</li>
                        <li>H0: Datele urmează o distribuție normală</li>
                        <li>H1: Datele nu urmează o distribuție normală</li>
                        <li>Nivel de semnificație: α = 0.05</li>
                    </ul>
                </div>
            </div>
        """, unsafe_allow_html=True)

    elif analysis_type == "Regresie multiplă":
        st.markdown("""
            <div class="method-box">
                <h3 class="method-title">📈 Regresie Multiplă</h3>
                <p>Regresia multiplă ne ajută să înțelegem cum mai multe factori influențează împreună o variabilă. De exemplu:</p>
                <ul>
                    <li>Cum afectează atât cantitatea cât și prețul exporturile totale?</li>
                    <li>Care sunt factorii cei mai importanți care influențează valoarea exporturilor?</li>
                </ul>
                <div class="formula-box">
                    <p class="formula-text">Modelul matematic: y = α + β₁X₁ + β₂X₂ + ... + βₙXₙ + ε</p>
                    <p>Unde:</p>
                    <ul>
                        <li>y: variabila dependentă (ex: valoarea exporturilor)</li>
                        <li>X₁, X₂, ..., Xₙ: variabilele independente (ex: cantități, prețuri)</li>
                        <li>β₁, β₂, ..., βₙ: coeficienții de regresie (impactul fiecărui factor)</li>
                        <li>α: interceptul (valoarea de bază)</li>
                        <li>ε: eroarea aleatorie</li>
                    </ul>
                </div>
                <div class="highlight-box">
                    <p><strong>💡 Sfaturi pentru interpretare:</strong></p>
                    <ul>
                        <li>R-squared (R²) arată cât de bine toate variabilele explică împreună variația</li>
                        <li>Adjusted R² ajustează R² pentru numărul de variabile</li>
                        <li>F-statistic testează semnificația generală a modelului</li>
                        <li>Coeficienții β arată impactul individual al fiecărei variabile</li>
                    </ul>
                </div>
            </div>
        """, unsafe_allow_html=True)

        # Selectarea variabilelor
        numeric_columns = data.select_dtypes(include=['number']).columns
        st.markdown('<p class="select-label">🎯 Selectează variabilele pentru regresie multiplă:</p>', unsafe_allow_html=True)
        
        y_var = st.selectbox("Variabilă dependentă (y):", numeric_columns)
        X_vars = st.multiselect("Variabile independente (X):", numeric_columns)

        if len(X_vars) > 0:
            # Pregătirea datelor
            X = data[X_vars]
            y = data[y_var]

            # Crearea și antrenarea modelului cu scikit-learn
            model_sklearn = LinearRegression()
            model_sklearn.fit(X, y)

            # Calcularea predicțiilor și metricilor
            y_pred = model_sklearn.predict(X)
            r2_score = model_sklearn.score(X, y)

            # Afișarea rezultatelor scikit-learn
            st.markdown('<p class="elegant-text">📊 Rezultatele Regresiei Multiple</p>', unsafe_allow_html=True)
            
            # Crearea unui DataFrame cu coeficienții
            coef_df = pd.DataFrame({
                'Variabilă': X_vars,
                'Coeficient': model_sklearn.coef_
            })
            
            st.markdown("""
                <div class="info-box">
                    <h3>Coeficienții modelului:</h3>
                    <p>Fiecare coeficient arată cât de mult se modifică variabila dependentă când variabila independentă crește cu 1 unitate, ținând cont de celelalte variabile.</p>
                </div>
            """, unsafe_allow_html=True)
            st.dataframe(coef_df)
            
            st.markdown(f"""
                <div class="info-box">
                    <h3>Metrici de Performanță:</h3>
                    <p>• Coeficientul de determinare (R²): {r2_score:.4f}</p>
                    <p>• Interceptul (α): {model_sklearn.intercept_:.4f}</p>
                    <div class="highlight-box">
                        <p><strong>Interpretare:</strong></p>
                        <ul>
                            <li>Modelul explică {r2_score*100:.1f}% din variația în {y_var}</li>
                            <li>Valoarea de bază (când toate X = 0) este {model_sklearn.intercept_:.4f}</li>
                        </ul>
                    </div>
                </div>
            """, unsafe_allow_html=True)

            # Vizualizarea reziduurilor
            st.markdown('<p class="elegant-text">🔍 Analiza Reziduurilor</p>', unsafe_allow_html=True)
            residuals = y - y_pred
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
            
            # Graficul reziduurilor vs valori prezise
            ax1.scatter(y_pred, residuals, alpha=0.5)
            ax1.axhline(y=0, color='r', linestyle='--')
            ax1.set_xlabel('Valori prezise')
            ax1.set_ylabel('Reziduuri')
            ax1.set_title('Graficul reziduurilor')
            ax1.grid(True, alpha=0.3)
            
            # Histograma reziduurilor
            ax2.hist(residuals, bins=30, alpha=0.7)
            ax2.set_xlabel('Reziduuri')
            ax2.set_ylabel('Frecvență')
            ax2.set_title('Distribuția reziduurilor')
            ax2.grid(True, alpha=0.3)
            
            st.pyplot(fig)

            # Adăugăm analiza cu statsmodels
            st.markdown('<p class="elegant-text">📊 Analiza Statistică Detaliată</p>', unsafe_allow_html=True)
            
            # Pregătirea datelor pentru statsmodels
            X_with_const = sm.add_constant(X)
            model_sm = sm.OLS(y, X_with_const).fit()

            # Afișarea rezultatelor statsmodels
            st.markdown("""
                <div class="info-box">
                    <h3>Metrici Avansate:</h3>
                    <p>• R-squared: {:.4f}</p>
                    <p>• Adjusted R-squared: {:.4f}</p>
                    <p>• F-statistic: {:.4f}</p>
                    <p>• Prob (F-statistic): {:.4f}</p>
                    <div class="highlight-box">
                        <p><strong>Interpretare:</strong></p>
                        <ul>
                            <li>R-squared ajustat este mai mic decât R-squared normal, reflectând numărul de variabile</li>
                            <li>F-statistic testează dacă modelul este semnificativ statistic</li>
                            <li>Prob (F-statistic) arată probabilitatea ca modelul să nu fie semnificativ</li>
                        </ul>
                    </div>
                </div>
            """.format(
                model_sm.rsquared,
                model_sm.rsquared_adj,
                model_sm.fvalue,
                model_sm.f_pvalue
            ), unsafe_allow_html=True)

            # Afișarea tabelului de rezultate detaliat
            st.markdown("""
                <div class="info-box">
                    <h3>Tabelul de Rezultate Detaliat:</h3>
                    <p>Acest tabel oferă statistici detaliate pentru fiecare coeficient, inclusiv erori standard și intervale de încredere.</p>
                </div>
            """, unsafe_allow_html=True)
            st.text(model_sm.summary().as_text())

            # Testul de normalitate a reziduurilor
            _, p_value = stats.shapiro(model_sm.resid)
            
            st.markdown(f"""
                <div class="info-box">
                    <h3>Testul de Normalitate a Reziduurilor (Shapiro-Wilk):</h3>
                    <p>• p-value: {p_value:.4f}</p>
                    <p>• Interpretare: {"Reziduurile par a urma o distribuție normală" if p_value > 0.05 else "Reziduurile nu urmează o distribuție normală"}</p>
                    <div class="highlight-box">
                        <p><strong>Explicație:</strong></p>
                        <ul>
                            <li>Folosim testul Shapiro-Wilk pentru verificarea normalității</li>
                            <li>H0: Datele urmează o distribuție normală</li>
                            <li>H1: Datele nu urmează o distribuție normală</li>
                            <li>Nivel de semnificație: α = 0.05</li>
                        </ul>
                    </div>
                </div>
            """, unsafe_allow_html=True)

            # Testul de heteroscedasticitate
            _, p_value, _, _ = het_breuschpagan(model_sm.resid, X_with_const)
            
            st.markdown("""
                <div class="info-box">
                    <h3>Testul de Heteroscedasticitate (Breusch-Pagan):</h3>
                    <p>• p-value: {:.4f}</p>
                    <p>• Interpretare: {}</p>
                    <div class="highlight-box">
                        <p><strong>Explicație:</strong></p>
                        <ul>
                            <li>Heteroscedasticitatea apare când variația erorilor nu este constantă</li>
                            <li>Poate afecta eficiența estimărilor și validitatea testelor statistice</li>
                        </ul>
                    </div>
                </div>
            """.format(
                p_value,
                "Nu există heteroscedasticitate" if p_value > 0.05 else "Există heteroscedasticitate"
            ), unsafe_allow_html=True)

    elif analysis_type == "Regresie logistică":
        st.markdown("""
            <div class="method-box">
                <h3 class="method-title">📈 Regresie Logistică</h3>
                <p>Regresia logistică ne ajută să clasificăm țările în două categorii bazate pe nivelul exporturilor. De exemplu:</p>
                <ul>
                    <li>Care țări au exporturi mari vs mici?</li>
                    <li>Ce factori influențează probabilitatea de a avea exporturi mari?</li>
                </ul>
                <div class="formula-box">
                    <p class="formula-text">Modelul matematic folosește funcția sigmoidă:</p>
                    <p>P(y=1|X) = 1 / (1 + e^(-(α + βX)))</p>
                    <p>Unde:</p>
                    <ul>
                        <li>P(y=1|X): probabilitatea ca y să fie 1 dat fiind X</li>
                        <li>α: interceptul</li>
                        <li>β: coeficienții de regresie</li>
                        <li>X: variabilele independente</li>
                    </ul>
                </div>
                <div class="highlight-box">
                    <p><strong>💡 Sfaturi pentru interpretare:</strong></p>
                    <ul>
                        <li>Acuratețea arată procentul de predicții corecte pe setul de testare</li>
                        <li>Coeficienții β indică direcția și puterea influenței</li>
                        <li>Matricea de confuzie arată predicțiile corecte vs greșite</li>
                    </ul>
                </div>
            </div>
        """, unsafe_allow_html=True)

        # Crearea variabilei binare pentru clasificare
        data['high_export'] = (data['chocolate_t'] > data['chocolate_t'].median()).astype(int)

        # Selectarea variabilelor pentru regresie logistică
        # Excludem variabilele care nu ar trebui să fie folosite ca predictori
        excluded_vars = ['high_export', 'chocolate_t', 'year']
        available_columns = [col for col in data.select_dtypes(include=['number']).columns 
                           if col not in excluded_vars]
        
        st.markdown('<p class="select-label">🎯 Selectează variabilele pentru regresie logistică:</p>', unsafe_allow_html=True)
        X_vars = st.multiselect("Variabile independente (X):", available_columns)

        if len(X_vars) > 0:
            # Pregătirea datelor
            X = data[X_vars]
            y = data['high_export']

            # Împărțirea datelor în set de antrenare și testare (70% - 30%)
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

            # Crearea și antrenarea modelului
            model = LogisticRegression(random_state=42)
            model.fit(X_train, y_train)

            # Calcularea predicțiilor și metricilor pe setul de testare
            y_pred = model.predict(X_test)
            accuracy = model.score(X_test, y_test)

            # Afișarea rezultatelor
            st.markdown('<p class="elegant-text">📊 Rezultatele Regresiei Logistice</p>', unsafe_allow_html=True)
            
            # Crearea unui DataFrame cu coeficienții
            coef_df = pd.DataFrame({
                'Variabilă': X_vars,
                'Coeficient': model.coef_[0]
            })
            
            st.markdown("""
                <div class="info-box">
                    <h3>Coeficienții modelului:</h3>
                    <p>Fiecare coeficient arată cât de mult crește logaritmul probabilității de a avea exporturi mari când variabila crește cu 1 unitate.</p>
                </div>
            """, unsafe_allow_html=True)
            st.dataframe(coef_df)
            
            st.markdown(f"""
                <div class="info-box">
                    <h3>Metrici de Performanță:</h3>
                    <p>• Acuratețea modelului pe setul de testare: {accuracy:.4f}</p>
                    <div class="highlight-box">
                        <p><strong>Interpretare:</strong></p>
                        <ul>
                            <li>Modelul prezice corect {accuracy*100:.1f}% din cazurile din setul de testare</li>
                            <li>Acest scor ar trebui comparat cu acuratețea unui model aleatoriu (50%)</li>
                            <li>Evaluarea este făcută pe date noi (setul de testare) pentru a evita supraantrenarea</li>
                        </ul>
                    </div>
                </div>
            """, unsafe_allow_html=True)

            # Matricea de confuzie pentru setul de testare
            cm = confusion_matrix(y_test, y_pred)
            
            st.markdown("""
                <div class="info-box">
                    <h3>Matricea de Confuzie (pe setul de testare):</h3>
                    <p>Arată predicțiile corecte vs greșite pentru fiecare clasă:</p>
                    <ul>
                        <li>True Negatives (stânga sus): predicții corecte pentru exporturi mici</li>
                        <li>False Positives (dreapta sus): predicții greșite pentru exporturi mari</li>
                        <li>False Negatives (stânga jos): predicții greșite pentru exporturi mici</li>
                        <li>True Positives (dreapta jos): predicții corecte pentru exporturi mari</li>
                    </ul>
                </div>
            """, unsafe_allow_html=True)
            
            fig, ax = plt.subplots(figsize=(8, 6))
            im = ax.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
            ax.set_title('Matricea de confuzie (set de testare)')
            
            # Adăugăm valorile în celule
            thresh = cm.max() / 2.
            for i in range(cm.shape[0]):
                for j in range(cm.shape[1]):
                    ax.text(j, i, format(cm[i, j], 'd'),
                            ha="center", va="center",
                            color="white" if cm[i, j] > thresh else "black")
                            
            plt.colorbar(im)
            ax.set_ylabel('Valori reale')
            ax.set_xlabel('Valori prezise')
            ax.set_xticks([0, 1])
            ax.set_yticks([0, 1])
            ax.set_xticklabels(['Export Mic', 'Export Mare'])
            ax.set_yticklabels(['Export Mic', 'Export Mare'])
            st.pyplot(fig)

            # Adăugăm metrici suplimentare de evaluare
            precision = precision_score(y_test, y_pred)
            recall = recall_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred)
            
            st.markdown(f"""
                <div class="info-box">
                    <h3>Metrici Adiționale de Evaluare:</h3>
                    <p>• Precizie: {precision:.4f}</p>
                    <p>• Recall (Sensibilitate): {recall:.4f}</p>
                    <p>• F1-Score: {f1:.4f}</p>
                    <div class="highlight-box">
                        <p><strong>Interpretare:</strong></p>
                        <ul>
                            <li>Precizia arată câte dintre predicțiile pozitive sunt corecte</li>
                            <li>Recall-ul arată câte dintre cazurile real pozitive au fost identificate</li>
                            <li>F1-Score este media armonică între precizie și recall</li>
                        </ul>
                    </div>
                </div>
            """, unsafe_allow_html=True)

    else:  # Clusterizare
        st.markdown("""
            <div class="method-box">
                <h3 class="method-title">🔍 Clusterizare</h3>
                <p>Clusterizarea ne ajută să identificăm grupe naturale de țări cu comportamente similare în ceea ce privește exporturile. De exemplu:</p>
                <ul>
                    <li>Care țări au profile similare de export?</li>
                    <li>Există grupuri distincte de țări bazate pe volumele de export?</li>
                </ul>
                <div class="formula-box">
                    <p class="formula-text">Algoritmul K-means:</p>
                    <p>1. Inițializează k centroizi aleator</p>
                    <p>2. Asignează fiecare punct la cel mai apropiat centroid</p>
                    <p>3. Actualizează pozițiile centroizilor</p>
                    <p>4. Repetă pașii 2-3 până la convergență</p>
                </div>
                <div class="highlight-box">
                    <p><strong>💡 Sfaturi pentru interpretare:</strong></p>
                    <ul>
                        <li>Silhouette Score măsoară calitatea clusterizării (0-1)</li>
                        <li>Statisticile per cluster arată caracteristicile fiecărui grup</li>
                        <li>Vizualizarea ajută la înțelegerea structurii grupurilor</li>
                    </ul>
                </div>
            </div>
        """, unsafe_allow_html=True)

        # Selectarea variabilelor pentru clusterizare
        numeric_columns = data.select_dtypes(include=['number']).columns
        st.markdown('<p class="select-label">🎯 Selectează variabilele pentru clusterizare:</p>', unsafe_allow_html=True)
        
        cluster_vars = st.multiselect("Variabile pentru clusterizare:", numeric_columns)
        n_clusters = st.slider("Număr de clustere:", min_value=2, max_value=10, value=3)

        if len(cluster_vars) > 0:
            # Pregătirea datelor
            X = data[cluster_vars]
            
            # Standardizarea datelor
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)

            # Aplicarea K-means
            kmeans = KMeans(n_clusters=n_clusters, random_state=42)
            clusters = kmeans.fit_predict(X_scaled)

            # Adăugarea clusterelor în DataFrame
            data['Cluster'] = clusters

            # Afișarea rezultatelor
            st.markdown('<p class="elegant-text">📊 Rezultatele Clusterizării</p>', unsafe_allow_html=True)
            
            # Statistici pentru fiecare cluster
            cluster_stats = data.groupby('Cluster')[cluster_vars].mean()
            st.markdown("""
                <div class="info-box">
                    <h3>Statistici pentru fiecare cluster:</h3>
                    <p>Acest tabel arată valorile medii pentru fiecare variabilă în fiecare cluster, ajutând la identificarea caracteristicilor distinctive ale fiecărui grup.</p>
                </div>
            """, unsafe_allow_html=True)
            st.dataframe(cluster_stats)

            # Vizualizarea clusterelor
            if len(cluster_vars) == 2:
                st.markdown("""
                    <div class="info-box">
                        <h3>Vizualizarea Clusterelor:</h3>
                        <p>Acest grafic arată distribuția punctelor în spațiul bidimensional, cu culori diferite pentru fiecare cluster.</p>
                        <div class="highlight-box">
                            <p><strong>Cum să interpretezi acest grafic:</strong></p>
                            <ul>
                                <li><strong>Culori diferite:</strong> Fiecare culoare reprezintă un cluster distinct de țări cu caracteristici similare</li>
                                <li><strong>Poziționare:</strong> Punctele apropiate indică țări cu valori similare pentru variabilele analizate</li>
                                <li><strong>Separare:</strong> Cu cât clusterele sunt mai bine separate, cu atât gruparea este mai clară și mai semnificativă</li>
                                <li><strong>Densitate:</strong> Zonele cu multe puncte indică pattern-uri comune în datele analizate</li>
                            </ul>
                        </div>
                    </div>
                """, unsafe_allow_html=True)

                fig, ax = plt.subplots(figsize=(10, 6))
                scatter = ax.scatter(X[cluster_vars[0]], X[cluster_vars[1]], 
                                   c=clusters, cmap='viridis')
                ax.set_xlabel(cluster_vars[0])
                ax.set_ylabel(cluster_vars[1])
                ax.set_title('Vizualizarea clusterelor')
                plt.colorbar(scatter)
                st.pyplot(fig)

                # Adăugăm interpretare detaliată pentru fiecare cluster
                for cluster_id in range(n_clusters):
                    cluster_data = data[data['Cluster'] == cluster_id]
                    cluster_center = kmeans.cluster_centers_[cluster_id]
                    
                    st.markdown(f"""
                        <div style='background-color: rgba(76, 175, 80, 0.1); border-left: 4px solid #4CAF50; padding: 20px; margin: 15px 0; border-radius: 5px;'>
                            <h3 style='color: #4CAF50; font-size: 24px; margin-bottom: 15px;'>
                                📊 Analiza Cluster {cluster_id}
                            </h3>
                            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Caracteristici:</h4>
                                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                                    <li><strong>Număr de țări:</strong> {len(cluster_data)}</li>
                                    <li><strong>Centrul clusterului:</strong></li>
                                    <ul>
                                        <li>{cluster_vars[0]}: {cluster_center[0]:.2f}</li>
                                        <li>{cluster_vars[1]}: {cluster_center[1]:.2f}</li>
                                    </ul>
                                    <li><strong>Țări reprezentative:</strong> {', '.join(cluster_data['country'].head(3).tolist())}</li>
                                </ul>
                            </div>
                            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Interpretare:</h4>
                                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                                    <li><strong>Comportament:</strong> {
                                        'Țări cu valori ridicate pentru ambele variabile' if all(x > 0 for x in cluster_center)
                                        else 'Țări cu valori scăzute pentru ambele variabile' if all(x < 0 for x in cluster_center)
                                        else 'Țări cu comportament mixt'
                                    }</li>
                                    <li><strong>Dispersie:</strong> {
                                        'Cluster compact, țări foarte similare' if len(cluster_data) < len(data)/n_clusters
                                        else 'Cluster mare, mai multă variabilitate între țări'
                                    }</li>
                                    <li><strong>Semnificație:</strong> {
                                        'Grup distinct cu caracteristici clare' if len(cluster_data) > 2
                                        else 'Posibil grup special sau outlieri'
                                    }</li>
                                </ul>
                            </div>
                        </div>
                    """, unsafe_allow_html=True)

            # Adăugăm interpretare generală a clusterizării
            st.markdown("""
                <div style='background-color: rgba(76, 175, 80, 0.1); border-left: 4px solid #4CAF50; padding: 20px; margin: 15px 0; border-radius: 5px;'>
                    <h3 style='color: #4CAF50; font-size: 24px; margin-bottom: 15px;'>
                        🔍 Interpretare Generală a Clusterizării
                    </h3>
                    <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                        <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Observații Cheie:</h4>
                        <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                            <li><strong>Separarea Clusterelor:</strong> Indică cât de distincte sunt grupurile de țări</li>
                            <li><strong>Pattern-uri:</strong> Evidențiază relațiile între variabilele analizate</li>
                            <li><strong>Grupări Naturale:</strong> Arată cum se organizează țările în funcție de caracteristicile lor</li>
                            <li><strong>Outlieri:</strong> Identifică țări cu comportament neobișnuit sau special</li>
                        </ul>
                    </div>
                    <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                        <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Implicații pentru Business:</h4>
                        <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                            <li><strong>Segmentare:</strong> Permite identificarea grupurilor de țări cu comportament similar</li>
                            <li><strong>Strategii:</strong> Ajută la dezvoltarea strategiilor specifice pentru fiecare grup</li>
                            <li><strong>Oportunități:</strong> Evidențiază potențiale piețe țintă sau oportunități de dezvoltare</li>
                            <li><strong>Monitorizare:</strong> Facilitează urmărirea performanței și evoluției grupurilor de țări</li>
                        </ul>
                    </div>
                </div>
            """, unsafe_allow_html=True)

            # Silhouette score
            silhouette_avg = silhouette_score(X_scaled, clusters)
            st.markdown(f"""
                <div class="info-box">
                    <h3>Calitatea Clusterizării:</h3>
                    <p>• Silhouette Score: {silhouette_avg:.4f}</p>
                    <div class="highlight-box">
                        <p><strong>Interpretare:</strong></p>
                        <ul>
                            <li>Scorul variază între -1 și 1</li>
                            <li>Valori apropiate de 1 indică clustere bine separate</li>
                            <li>Valori apropiate de 0 indică suprapunere între clustere</li>
                            <li>Valori negative indică posibile clasificări greșite</li>
                        </ul>
                    </div>
                </div>
            """, unsafe_allow_html=True)

            # Distribuția țărilor pe clustere
            st.markdown("""
                <div class="info-box">
                    <h3>Distribuția Țărilor pe Clustere:</h3>
                    <p>Această analiză arată cum sunt distribuite țările între diferitele clustere identificate.</p>
                </div>
            """, unsafe_allow_html=True)

            cluster_distribution = data.groupby(['Cluster', 'country']).size().reset_index(name='count')
            for cluster in range(n_clusters):
                countries_in_cluster = cluster_distribution[cluster_distribution['Cluster'] == cluster]['country'].tolist()
                st.markdown(f"""
                    <div class="method-box">
                        <h4 style="color: #4CAF50;">Cluster {cluster}:</h4>
                        <p>Țări: {', '.join(countries_in_cluster)}</p>
                        <p>Număr de țări: {len(countries_in_cluster)}</p>
                    </div>
                """, unsafe_allow_html=True)

            # Caracteristici distinctive ale clusterelor
            st.markdown("""
                <div class="info-box">
                    <h3>Caracteristici Distinctive ale Clusterelor:</h3>
                    <p>Pentru fiecare cluster, vom analiza valorile medii și deviațiile standard ale variabilelor selectate.</p>
                </div>
            """, unsafe_allow_html=True)

            for cluster in range(n_clusters):
                cluster_data = data[data['Cluster'] == cluster]
                st.markdown(f"""
                    <div class="method-box">
                        <h4 style="color: #4CAF50;">Analiza Cluster {cluster}:</h4>
                    </div>
                """, unsafe_allow_html=True)
                
                # Statistici descriptive pentru cluster
                cluster_stats = cluster_data[cluster_vars].describe()
                st.write(f"Statistici pentru Cluster {cluster}:")
                st.dataframe(cluster_stats)

                # Vizualizare distribuției variabilelor în cluster
                if len(cluster_vars) > 0:
                    fig, ax = plt.subplots(figsize=(10, 6))
                    cluster_data[cluster_vars].boxplot(ax=ax)
                    plt.xticks(rotation=45)
                    plt.title(f'Distribuția variabilelor în Cluster {cluster}')
                    st.pyplot(fig)

                    # Adăugăm interpretarea box plot-urilor pentru clustere
                    st.markdown(f"""
                        <div style='background-color: rgba(76, 175, 80, 0.1); border-left: 4px solid #4CAF50; padding: 20px; margin: 15px 0; border-radius: 5px;'>
                            <h3 style='color: #4CAF50; font-size: 24px; margin-bottom: 15px;'>
                                📊 Interpretarea Box Plot-urilor pentru Cluster {cluster}
                            </h3>
                            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px;'>
                                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Cum să interpretezi:</h4>
                                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                                    <li><strong>Cutia (Box):</strong>
                                        <ul>
                                            <li>Marginea de jos: Reprezintă primul quartil (Q1, 25% din date)</li>
                                            <li>Linia din mijloc: Reprezintă mediana (Q2, 50% din date)</li>
                                            <li>Marginea de sus: Reprezintă al treilea quartil (Q3, 75% din date)</li>
                                        </ul>
                                    </li>
                                    <li><strong>Mustățile (Whiskers):</strong>
                                        <ul>
                                            <li>Se extind până la valorile minime și maxime care nu sunt considerate outlieri</li>
                                            <li>Lungimea lor indică dispersia datelor în cluster</li>
                                        </ul>
                                    </li>
                                    <li><strong>Punctele:</strong> Reprezintă valorile extreme (outlieri) din cluster</li>
                                </ul>
                            </div>
                            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Ce să urmărești:</h4>
                                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                                    <li><strong>Poziția mediană:</strong> Indică tendința centrală a clusterului pentru fiecare variabilă</li>
                                    <li><strong>Înălțimea cutiei:</strong> Arată variabilitatea datelor - cu cât e mai înaltă, cu atât datele sunt mai dispersate</li>
                                    <li><strong>Simetria:</strong> Dacă mediana este în centrul cutiei, distribuția este simetrică</li>
                                    <li><strong>Outlieri:</strong> Punctele izolate indică țări cu valori neobișnuite în acest cluster</li>
                                </ul>
                            </div>
                            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Caracteristici specifice acestui cluster:</h4>
                                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                                    {cluster_specific_interpretations(cluster_data, cluster_vars)}
                                </ul>
                            </div>
                            <div style='background-color: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 5px; margin-top: 10px;'>
                                <h4 style='color: #4CAF50; font-size: 20px; margin-bottom: 10px;'>Implicații pentru Business:</h4>
                                <ul style='color: #e0e0e0; font-size: 16px; line-height: 1.6;'>
                                    <li><strong>Omogenitate:</strong> Cât de similare sunt țările din acest cluster</li>
                                    <li><strong>Potențial:</strong> Identificarea oportunităților bazate pe performanța clusterului</li>
                                    <li><strong>Riscuri:</strong> Evidențierea variabilității și a potențialelor anomalii</li>
                                    <li><strong>Strategii:</strong> Dezvoltarea abordărilor specifice pentru acest grup de țări</li>
                                </ul>
                            </div>
                        </div>
                    """, unsafe_allow_html=True)









